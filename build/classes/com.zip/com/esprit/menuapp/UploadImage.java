/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.esprit.menuapp;

import static com.codename1.io.rest.Rest.options;


/**
 *
 * @author alaagha
 */
public class UploadImage {
    //options.setResize(width, height, keepAspectRatio);
    
//    options = new ImageOptions();
//    //options.setResize(width, height, keepAspectRatio);
//    
//    option.setFieldname('my-custom-fieldname');
//    option.getFieldname();
//    
//    options.setValidation(new ImageValidation());
//    options.setValidation(new ImageValidation(new String[] { "gif", "jpeg" }, new String[] { "image/gif", "image/jpeg" }));
//    options.setValidation(new ImageValidation(new CustomValidation() {  @Override  public boolean validate(String filePath, String mimeType) {  }}));
//}options.getValidation();
//    
//    /// Allowed image validation default extensions.public static final String[] allowedImageExtsDefault = new String[] { "gif", "jpeg", "jpg", "png", "svg", "blob" };/// Allowed image validation default mimetypes.public static final String[] allowedImageMimeTypesDefault = new String[] { "image/gif", "image/jpeg", "image/pjpeg", "image/x-png", "image/png", "image/svg+xml" };
//    
//    ResizeOptions resizeOptions = options.new ResizeOptions();
//    resizeOptions.setNewWidth(300);resizeOptions.setNewHeight(400);
//    resizeOptions.setKeepAspectRatio(true);
//    options.setResizeOptions(resizeOptions);
//    options.setResize(300, 400, true);options.getResizeOptions();
//    
//    Map<Object, Object> responseData;try {  responseData = Image.upload(request, fileRoute, options);
//}
//    catch (Exception e)
//    {e.printStackTrace();  responseData = new HashMap();
//    //responseData.put("error", e.toString());}String jsonResponseData = new Gson().toJson(responseData);
//    response.setContentType("application/json");
//    response.setCharacterEncoding("UTF-8");response.getWriter().write(jsonResponseData);
//    
//    
//String jsonResponseData = new Gson().toJson(responseData);
//response.setContentType("application/json");
//response.setCharacterEncoding("UTF-8");
//response.getWriter().write(jsonResponseData);
//    
//ArrayList<Object> responseData;try {  responseData = Image.list(request, fileRoute);
//} catch (Exception e) 
//{  e.printStackTrace();  
//response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);  
//return;
//}
//String jsonResponseData = new Json().toJson(responseData);
//response.setContentType("application/json");response.setCharacterEncoding("UTF-8");response.getWriter().write(jsonResponseData);
}
